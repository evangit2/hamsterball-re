# mknp_textures_plus

A Hamsterball Plus mod. Empty scaffold v01a — does nothing yet.
Install: copy `mknp_textures_plus.dll` into the game's
`Mods/` folder (Hamsterball Plus required).

## What it does

Nothing for now. Placeholder for future texture work.
Loads clean, writes `mknp_textures_plus.log` (INIT line) next to
the dll, exposes one toggle (`Textures Plus`).

## Log

`mknp_textures_plus.log` is written next to this dll (the `Mods/`
folder): INIT + toggle ON/OFF. Send it back if the mod won't load.

## Technical details

- HB+ v2.1, MinGW build: nocrt + manual 17-entry vtable, KERNEL32 only
- `source/` holds `.cpp` (HB+ build, shipped)

## Build

```sh
cd source && bash build.sh
```
